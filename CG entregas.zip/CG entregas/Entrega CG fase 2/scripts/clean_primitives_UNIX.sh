#!/bin/sh

rm -f "./*.3d"