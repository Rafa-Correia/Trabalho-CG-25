Before running the engine with any of these, ensure that you run the adequate scripts in the "./scripts" folder.

If running solar system mockup config, run "./scripts/solar_system_setup_{OS}.{EXT}".
Otherwise, run "./scripts/generate_all_primitives_{OS}.{EXT}".
To clean all generated primitives, run "./scripts/clean_primitives_{OS}.{EXT}".