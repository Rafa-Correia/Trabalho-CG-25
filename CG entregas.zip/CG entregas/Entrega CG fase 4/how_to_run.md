# Instructions

In the `config` folder, we provide a set of configuration files to test the engine.

> **Important:** Always run everything from the **root folder** (where this instructions file is located)!

---

## Mesh Generation

The scenes rely on pre-existing meshes. To generate them, we’ve included a few helper scripts.

<details>
<summary>How to use the scripts</summary>

- Scripts are located in the `scripts` folder
- Run them using a terminal **from the root folder**
- They assume the `generator` app is located in the `bin` folder

If your compiled generator is somewhere else, you can either:

- Edit the scripts to point to the correct location (recommended)
  **or**
- Move the compiled apps to the `bin` folder

</details>

---

## Running the Engine

To run the engine with a configuration file, use the following command:

```bash
{path to engine}/engine.exe ./config/{desired_config_file}
```

The engine has a set of instructions itself, to see them, simply press 'P' to print the instruction to the console!
