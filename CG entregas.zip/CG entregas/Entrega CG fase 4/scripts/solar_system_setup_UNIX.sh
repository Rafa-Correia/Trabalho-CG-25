#!/bin/sh

SUBFOLDER="bin"
EXECUTABLE="generator"

SPHERE_ARGS="sphere 1 100 100 sphere.3d"
TORUS_ARGS="torus 1.0 1.25 100 100 torus.3d"
PATCH_ARGS="patch teapot.patch 20 patch.3d"


"./$SUBFOLDER/$EXECUTABLE" $SPHERE_ARGS
"./$SUBFOLDER/$EXECUTABLE" $TORUS_ARGS
"./$SUBFOLDER/$EXECUTABLE" $PATCH_ARGS